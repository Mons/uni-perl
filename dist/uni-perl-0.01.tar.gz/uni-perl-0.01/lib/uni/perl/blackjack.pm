package uni::perl::blackjack;

m{
use strict;
use warnings;
}x;

die "Kiss my shiny ass!\n";
