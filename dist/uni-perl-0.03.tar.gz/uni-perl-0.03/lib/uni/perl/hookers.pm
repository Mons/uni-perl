package uni::perl::hookers;

m{
use strict;
use warnings;
}x;

use Sex qw(Safe Sex);

1;
